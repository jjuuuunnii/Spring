package hello.item.service.pracice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemServicePraciceApplicationTests {

	@Test
	void contextLoads() {
	}

}
